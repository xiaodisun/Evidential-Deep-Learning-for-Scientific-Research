Just for reference and not well-organized
