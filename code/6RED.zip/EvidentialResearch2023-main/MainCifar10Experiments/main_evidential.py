'''Train CIFAR10 with PyTorch.'''
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import torchvision
import torchvision.transforms as transforms

import os
import numpy as np

from utilFiles.get_args import the_args
args = the_args()
from utilFiles.set_deterministic import make_deterministic
make_deterministic(args.seed)
from utilFiles.losses import edl_mse_loss, edl_digamma_loss, edl_log_loss

from models import *
from utils import progress_bar

device = args.device
best_acc = 0  # best test accuracy
start_epoch = 0  # start from epoch 0 or last checkpoint epoch

# Data
print('==> Preparing data..')
transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

trainset = torchvision.datasets.CIFAR10(
    root='./data', train=True, download=True, transform=transform_train)
trainloader = torch.utils.data.DataLoader(
    trainset, batch_size=128, shuffle=True, num_workers=2)

testset = torchvision.datasets.CIFAR10(
    root='./data', train=False, download=True, transform=transform_test)
testloader = torch.utils.data.DataLoader(
    testset, batch_size=100, shuffle=False, num_workers=2)

classes = ('plane', 'car', 'bird', 'cat', 'deer',
           'dog', 'frog', 'horse', 'ship', 'truck')

# Model
print('==> Building model..')
# net = VGG('VGG19')
net = ResNet18()
# net = PreActResNet18()
# net = GoogLeNet()
# net = DenseNet121()
# net = ResNeXt29_2x64d()
# net = MobileNet()
# net = MobileNetV2()
# net = DPN92()
# net = ShuffleNetG2()
# net = SENet18()
# net = ShuffleNetV2(1)
# net = EfficientNetB0()
# net = RegNetX_200MF()
# net = SimpleDLA()
net = net.to(device)
if device == 'cuda':
    net = torch.nn.DataParallel(net)
    cudnn.benchmark = True

if args.resume:
    # Load checkpoint.
    print('==> Resuming from checkpoint..')
    assert os.path.isdir('checkpoint'), 'Error: no checkpoint directory found!'
    checkpoint = torch.load('./checkpoint/ckpt.pth')
    net.load_state_dict(checkpoint['net'])
    best_acc = checkpoint['acc']
    start_epoch = checkpoint['epoch']

if args.uncertainty:
    if args.unc_type == "digamma":
        loss_function = edl_digamma_loss
    elif args.unc_type == "log":
        loss_function = edl_log_loss
    elif args.unc_type == "mse":
        loss_function = edl_mse_loss
    else:
        print("--uncertainty requires --mse, --log or --digamma.")
        raise NotImplementedError()
else:
    loss_function = nn.CrossEntropyLoss()
        
optimizer = optim.SGD(net.parameters(), lr=args.lr,
                      momentum=0.9, weight_decay=5e-4)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

# device = torch.device("cpu")
def one_hot_embedding(labels, num_classes=10):
    # Convert to One Hot Encoding
    # print("y: ", labels, "num classes: ", num_classes)
    y = torch.eye(num_classes).to(device)
    # print("y: ", y)
    
    return y[labels]

def get_loss( outputs, labels):
    
    num_classes = outputs.shape[-1]
    if args.uncertainty:
        y = one_hot_embedding(labels, num_classes)
        y = y.to(device)
        _, preds = torch.max(outputs, 1)
        loss = loss_function(
            outputs, y.float(), epoch, num_classes, 10, device
        )                 

    else:
        _, preds = torch.max(outputs, 1)
        loss = loss_function(outputs, labels)
    return loss


# Training
def train(epoch, save_dict):
    print('\nEpoch: %d' % epoch)
    net.train()
    train_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = net(inputs)
        loss = get_loss( outputs, targets)

        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        progress_bar(batch_idx, len(trainloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                     % (train_loss/(batch_idx+1), 100.*correct/total, correct, total))
    save_dict['train_loss'] = train_loss/(batch_idx+1)
    save_dict['train_accuracy'] = 100.*correct/total
    
    return save_dict

from utilFiles.helper_functions import get_ece_evid, get_ece
def test(epoch, save_dict):
    global best_acc
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = net(inputs)
            loss = get_loss( outputs, targets)


            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                         % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))



        # print("ECE END")
    # Save checkpoint.
    acc = 100.*correct/total
    save_dict['test_loss'] = test_loss/(batch_idx+1)
    save_dict['test_accuracy'] = acc
    
    if acc > best_acc:
        print('Saving..')
        state = {
            'net': net.state_dict(),
            'acc': acc,
            'epoch': epoch,
        }
        if not os.path.isdir('checkpoint'):
            os.mkdir('checkpoint')
        torch.save(state, f'{args.save_path}/checkpoint_ckpt.pth')
        best_acc = acc
    return save_dict

import time
import shutil

checkpoint_path = "Evid_" + args.exp_save_name 

if os.path.exists(checkpoint_path):
    print("File exists. Removing: ", checkpoint_path)
    time.sleep(10)
    shutil.rmtree(checkpoint_path)

os.mkdir(checkpoint_path)

from utilFiles.helper_functions import save_to_csv

for epoch in range(start_epoch, start_epoch+200):
    save_dict = {}

    
    args.save_path = checkpoint_path
    
    save_dict['epoch'] = epoch
    save_dict = train(epoch, save_dict)
    save_dict = test(epoch, save_dict)
    
    scheduler.step()
    
    save_results_path = args.save_path + "/save_results.csv"
    save_to_csv(save_dict, save_results_path, start_epoch = start_epoch )
